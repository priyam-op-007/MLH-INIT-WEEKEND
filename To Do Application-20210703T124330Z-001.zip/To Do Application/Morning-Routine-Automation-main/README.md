# Morning-Routine-Automation

## Overview
This is the source code for my medium article: https://medium.com/@lucas-soares/automating-your-digital-morning-routine-with-python-8387fe884422

## Setup
Make sure you have pandas installed:

```pip install pandas```

I used python 3.8.8 but not reason why it would not work on any python 3.6+.

The scripts can be run separately or by running:

```python startday.py```

and if you want to run the keyboard and window tabs loggers run:

```python call_Start_and_Logs.py```







